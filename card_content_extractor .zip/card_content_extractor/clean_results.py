import csv

input_file = "results.csv"
output_file = "cleaned_results.csv"

with open(input_file, "r", encoding="utf-8") as infile, open(output_file, "w", newline="", encoding="utf-8") as outfile:
    reader = csv.DictReader(infile)
    fieldnames = reader.fieldnames
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()

    for row in reader:
       
        row["branch"] = row["branch"].replace("Valid Upto", "").strip()

        
        if row["name"].lower() == "not found" or row["roll_number"].lower() == "not found":
            continue

        writer.writerow(row)

print("Cleaned CSV created as cleaned_results.csv")