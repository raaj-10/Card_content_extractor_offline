import csv
from collections import Counter

file_path = "cleaned_results.csv"
total = 0
missing = {"name": 0, "roll_number": 0, "branch": 0, "valid_upto": 0}
branch_count = Counter()
valid_years = Counter()

with open(file_path, encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        total += 1

        for field in missing:
            if not row[field] or row[field].lower() == "not found":
                missing[field] += 1

        branch_count[row["branch"]] += 1
        if row["valid_upto"].isdigit():
            valid_years[row["valid_upto"]] += 1

print(f"\n Total Records: {total}")
print(f"\n Missing Fields Summary:")
for key, value in missing.items():
    print(f" - {key}: {value} missing")

print("\n Branch-wise Counts:")
for branch, count in branch_count.items():
    print(f" - {branch}: {count}")

if valid_years:
    common_year = valid_years.most_common(1)[0]
    print(f"\n Most common valid_upto year: {common_year[0]} ({common_year[1]} times)")