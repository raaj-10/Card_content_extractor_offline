import os
from PIL import Image
import pytesseract
import re
import csv
from datetime import datetime

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

patterns = {
    "name": r"NAME[\s:]*([A-Za-z ]+)",
    "roll_number": r"RollNo[:\s]*([0-9A-Z]+)",
    "branch": r"Branch[:\s]*([A-Za-z ]+)",
    "valid_upto": r"Valid Upto[:\s]*([0-9]{4})"
}

def extract_text(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    data = {}
    for field, pattern in patterns.items():
        match = re.search(pattern, text, re.IGNORECASE)
        data[field] = match.group(1).strip() if match else "Not found"
    data["timestamp"] = datetime.now().strftime("%d-%m-%Y %H:%M")
    return data

csv_file = "results.csv"
headers = ["name", "roll_number", "branch", "valid_upto", "timestamp"]
if not os.path.exists(csv_file):
    with open(csv_file, "w", newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(headers)


image_folder = "images_sample"
for filename in os.listdir(image_folder):
    if filename.endswith(".png") or filename.endswith(".jpg"):
        path = os.path.join(image_folder, filename)
        data = extract_text(path)
        with open(csv_file, "a", newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([data[field] for field in headers])

print(" Batch upload complete.")