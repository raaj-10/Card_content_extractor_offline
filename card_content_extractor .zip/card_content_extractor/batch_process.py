import os
import json
import base64
import requests
from datetime import datetime
import csv

# Paths
image_folder = "images_sample"
json_folder = "data_sample"
csv_file = "results.csv"

# Set FastAPI endpoint
endpoint = "http://127.0.0.1:8000/extract-id-info"

# CSV headers
headers = ["file_id", "name", "roll_number", "branch", "valid_upto", "timestamp"]
file_exists = os.path.isfile(csv_file)

with open(csv_file, mode="a", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    if not file_exists:
        writer.writerow(headers)

    for file in sorted(os.listdir(image_folder)):
        if not file.endswith(".png"):
            continue

        file_id = file.replace(".png", "")
        image_path = os.path.join(image_folder, file)
        json_path = os.path.join(json_folder, f"{file_id}.json")

        if not os.path.exists(json_path):
            continue

        with open(image_path, "rb") as img_file:
            image_bytes = img_file.read()
            image_base64 = base64.b64encode(image_bytes).decode("utf-8")

        payload = {"image_base64": image_base64}
        response = requests.post(endpoint, json=payload)

        if response.status_code == 200:
            result = response.json()
            extracted_data = result.get("extracted_data", {})

            row = [
                file_id,
                extracted_data.get("name", ""),
                extracted_data.get("roll_number", ""),
                extracted_data.get("branch", ""),
                extracted_data.get("valid_upto", ""),
                datetime.now().strftime("%d-%m-%Y %H:%M")
            ]
            writer.writerow(row)
        else:
            print(f"Failed for {file_id} with status {response.status_code}")