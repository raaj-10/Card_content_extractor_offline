from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from datetime import datetime
from fastapi.responses import FileResponse
from PIL import Image
import pytesseract
import os
import csv
import re

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

app = FastAPI()

app.mount("/picupload", StaticFiles(directory="picupload"), name="picupload")
templates = Jinja2Templates(directory="picupload")

patterns = {
    "name": r"NAME[\s:]*([A-Za-z\s]+)",
    "roll_number": r"RollNo[\s:]*([0-9A-Za-z]+)",
    "branch": r"Branch[\s:]*([A-Za-z\s-]+)",
    "valid_upto": r"(?:Valid Upto|Valid)[\s:]*([0-9]{4})"
}

cleanup_keywords = {
    "rollno": "RollNo",
    "branch": "Branch",
    "valid": "Valid Upto"
}

@app.get("/", response_class=HTMLResponse)
async def read_form(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/batch-extract")
async def batch_extract(request: Request):
    form = await request.form()
    files = form.getlist("files")
    timestamp = datetime.now().strftime("%d-%m-%Y %H:%M")

    extracted_rows = []
    errors = []

    allowed_extensions = {".png", ".jpg", ".jpeg"}

    junk_csv = "junk_log.csv"
    if not os.path.exists(junk_csv):
        with open(junk_csv, mode="w", newline="", encoding="utf-8") as junk_file:
            writer = csv.writer(junk_file)
            writer.writerow(["filename", "ocr_text", "timestamp"])

    for upload_file in files:
        filename = upload_file.filename
        ext = os.path.splitext(filename)[-1].lower()

        if ext not in allowed_extensions:
            errors.append(f"{filename}: Unsupported file format.")
            continue

        content = await upload_file.read()
        with open("input_image.png", "wb") as f:
            f.write(content)

        try:
            img = Image.open("input_image.png")
            ocr_text = pytesseract.image_to_string(img)
        except Exception:
            errors.append(f"{filename}: Could not process image.")
            continue

        cleaned_text = ocr_text.replace('\n', ' ').replace('\f', ' ').strip()
        for k, v in cleanup_keywords.items():
            cleaned_text = cleaned_text.replace(k, v)

        extracted_data = {}
        for field, pattern in patterns.items():
            match = re.search(pattern, cleaned_text, re.IGNORECASE)
            extracted_data[field] = match.group(1).strip() if match else "Not found"

        if all(val == "Not found" for val in extracted_data.values()):
            with open(junk_csv, mode="a", newline="", encoding="utf-8") as junk_file:
                writer = csv.writer(junk_file)
                writer.writerow([filename, cleaned_text, timestamp])
            errors.append(f"{filename}: No valid fields found.")
            continue

        extracted_data["timestamp"] = timestamp
        extracted_rows.append(extracted_data)

    cleaned_csv = "clean_results.csv"
    file_exists = os.path.exists(cleaned_csv)
    with open(cleaned_csv, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["name", "roll_number", "branch", "valid_upto", "timestamp"])
        for row in extracted_rows:
            writer.writerow([
                row["name"], row["roll_number"], row["branch"], row["valid_upto"], row["timestamp"]
            ])

    return templates.TemplateResponse("index.html", {
        "request": request,
        "message": f"{len(extracted_rows)} file(s) processed successfully.",
        "errors": errors,
        "results": extracted_rows
    })

@app.get("/download-cleaned")
def download_cleaned_csv():
    file_path = "clean_results.csv"
    if os.path.exists(file_path):
        return FileResponse(path=file_path, filename="clean_results.csv", media_type='text/csv')
    return {"error": "clean_results.csv not found"}

@app.get("/download-junk")
def download_junk_csv():
    file_path = "junk_log.csv"
    if os.path.exists(file_path):
        return FileResponse(path=file_path, filename="junk_log.csv", media_type='text/csv')
    return {"error": "junk_log.csv not found"}

@app.get("/download-results")
def download_results_csv():
    file_path = "results.csv"
    if os.path.exists(file_path):
        return FileResponse(path=file_path, filename="results.csv", media_type='text/csv')
    return {"error": "results.csv not found"}

@app.get("/results", response_class=HTMLResponse)
def show_results(request: Request):
    results = []
    file_path = "results.csv"
    if os.path.exists(file_path):
        with open(file_path, newline='', encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                results.append(row)
    return templates.TemplateResponse("results_view.html", {"request": request, "results": results})

@app.get("/history", response_class=HTMLResponse)
def view_history(request: Request):
    data_rows = []
    csv_file = "clean_results.csv"
    if os.path.exists(csv_file):
        with open(csv_file, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            data_rows = list(reader)

    return templates.TemplateResponse("history.html", {
        "request": request,
        "data": data_rows
    })